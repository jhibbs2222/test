// backend/eligibilityConfig.ts
// Pure offline configuration for state programs + charities.
// No network calls. No AI.

export type StateCode =
  | "AL" | "GA" | "FL" | "IL" | "KY" | "MA" | "ME" | "MO" | "MS"
  | "MT" | "NJ" | "NY" | "OH" | "OR" | "PA" | "SC" | "VA" | "WA"
  | "WV" | "WI";

export type CharityProgramId =
  | "PAN_FOUNDATION"
  | "HEALTHWELL_FOUNDATION"
  | "PAF_FINANCIAL_AID"
  | "NEEDYMEDS"
  | "NAFC_CLINICS"
  | "GA_GCCN"
  | "FL_FAFCC"
  | "VA_VAFCC";

export interface CharityProgram {
  id: CharityProgramId;
  name: string;
  scope: "national" | "state";
  states: StateCode[] | "ALL";
  type: "Rx/Diagnosis Assistance" | "Clinic/Charity Network" | "Other";
  targetPopulation: string;
  basicEligibility: string;
  url: string;
}

export interface StateConfig {
  code: StateCode;
  name: string;
  isMedicaidExpansion: boolean;
  /** Approximate adult Medicaid income limit in % FPL for expansion adults.
   *  For non-expansion states this can be 0 or ignored in your rules.
   */
  medicaidAdultFplLimit: number;
  medicaidUrl: string;
  chipUrl: string;
  marketplaceUrl: string;
  freeClinicSearchUrl: string;
  /** Placeholder – set this to your hospital system’s FAP page per facility */
  hospitalFapInfoUrl: string;
  /** IDs into CHARITY_PROGRAMS that you want to surface for this state */
  charityProgramIds: CharityProgramId[];
}

// -------------------- Charity catalog (offline) --------------------

export const CHARITY_PROGRAMS: Record<CharityProgramId, CharityProgram> = {
  PAN_FOUNDATION: {
    id: "PAN_FOUNDATION",
    name: "PAN Foundation",
    scope: "national",
    states: "ALL",
    type: "Rx/Diagnosis Assistance",
    targetPopulation:
      "Patients with specific serious or chronic diseases who struggle with out-of-pocket treatment costs.",
    basicEligibility:
      "Must have a diagnosis covered by an open PAN fund, meet that fund's medical criteria, have health insurance that covers the medication or treatment, and meet income limits (typically around 300–500% of the federal poverty level, depending on the fund).",
    url: "https://www.panfoundation.org/",
  },

  HEALTHWELL_FOUNDATION: {
    id: "HEALTHWELL_FOUNDATION",
    name: "HealthWell Foundation",
    scope: "national",
    states: "ALL",
    type: "Rx/Diagnosis Assistance",
    targetPopulation:
      "Patients with certain chronic or life-threatening diseases who need help with premiums, copays, or other insured costs.",
    basicEligibility:
      "Must have an eligible diagnosis supported by an active HealthWell fund, be insured, and have household income typically up to about 400–500% of the federal poverty level (exact limits and disease lists vary by fund).",
    url: "https://www.healthwellfoundation.org/",
  },

  PAF_FINANCIAL_AID: {
    id: "PAF_FINANCIAL_AID",
    name: "Patient Advocate Foundation – Financial Aid & Co-Pay Relief",
    scope: "national",
    states: "ALL",
    type: "Rx/Diagnosis Assistance",
    targetPopulation:
      "Patients with specific diseases or conditions who face financial hardship with their medical care.",
    basicEligibility:
      "Must meet medical criteria for one of PAF's active disease-specific funds and meet that fund's financial need requirements (income and cost burden). Grants are limited and often first-come, first-served while funds last.",
    url: "https://www.patientadvocate.org/financialaid/",
  },

  NEEDYMEDS: {
    id: "NEEDYMEDS",
    name: "NeedyMeds",
    scope: "national",
    states: "ALL",
    type: "Other",
    targetPopulation:
      "Anyone looking for prescription savings, patient assistance programs, and low-cost care resources.",
    basicEligibility:
      "No strict eligibility just to use the resource. NeedyMeds is a free, public database of drug assistance programs, disease-based help, and low-cost clinics. Each individual program listed on the site has its own guidelines.",
    url: "https://www.needymeds.org/",
  },

  NAFC_CLINICS: {
    id: "NAFC_CLINICS",
    name: "National Association of Free & Charitable Clinics – Clinic Directory",
    scope: "national",
    states: "ALL",
    type: "Clinic/Charity Network",
    targetPopulation:
      "Low-income, uninsured, or underinsured individuals needing free or low-cost primary or ongoing care.",
    basicEligibility:
      "Eligibility is set by each clinic, but generally they serve people who are uninsured or underinsured and meet income limits. Reps can search by city or ZIP to find nearby clinics and then follow each clinic’s intake process.",
    url: "https://nafcclinics.org/find-clinic/",
  },

  GA_GCCN: {
    id: "GA_GCCN",
    name: "Georgia Charitable Care Network (GCCN)",
    scope: "state",
    states: ["GA"],
    type: "Clinic/Charity Network",
    targetPopulation:
      "Georgia residents seeking care at free and charitable clinics that serve vulnerable and low-income populations.",
    basicEligibility:
      "Each member clinic sets its own eligibility, but in general they serve uninsured or underinsured Georgia residents with limited income. Use GCCN to locate appropriate clinics and then follow that clinic’s screening process.",
    url: "https://gacharitycare.org/",
  },

  FL_FAFCC: {
    id: "FL_FAFCC",
    name: "Florida Association of Free and Charitable Clinics (FAFCC)",
    scope: "state",
    states: ["FL"],
    type: "Clinic/Charity Network",
    targetPopulation:
      "Low-income, uninsured, and underserved Floridians seeking free or low-cost clinic services.",
    basicEligibility:
      "Eligibility varies by member clinic. Most clinics serve uninsured or underinsured patients with limited income. Use FAFCC’s resources to identify clinics and then follow the clinic’s intake and financial screening requirements.",
    url: "https://www.fafcc.org/",
  },

  VA_VAFCC: {
    id: "VA_VAFCC",
    name: "Virginia Association of Free & Charitable Clinics (VAFCC)",
    scope: "state",
    states: ["VA"],
    type: "Clinic/Charity Network",
    targetPopulation:
      "Virginia residents in need of free or reduced-cost health services through free and charitable clinics.",
    basicEligibility:
      "Eligibility is determined by each clinic, but generally focuses on low-income, uninsured, or underinsured adults. Use VAFCC resources to locate a clinic and then follow that clinic’s financial assistance process.",
    url: "https://www.vafreeclinics.org/",
  },
};

// Helper set for “default charities we show everywhere”
const BASE_CHARITY_IDS: CharityProgramId[] = [
  "PAN_FOUNDATION",
  "HEALTHWELL_FOUNDATION",
  "PAF_FINANCIAL_AID",
  "NEEDYMEDS",
  "NAFC_CLINICS",
];

// -------------------- State config (all 20 states) --------------------

export const STATE_CONFIG: Record<StateCode, StateConfig> = {
  AL: {
    code: "AL",
    name: "Alabama",
    isMedicaidExpansion: false,
    medicaidAdultFplLimit: 0,
    medicaidUrl: "https://medicaid.alabama.gov/",
    chipUrl: "https://insurealabama.adph.state.al.us/",
    marketplaceUrl: "https://www.healthcare.gov/marketplace-in-your-state/alabama/",
    freeClinicSearchUrl: "https://nafcclinics.org/find-clinic/",
    hospitalFapInfoUrl: "https://your-hospital.org/financial-assistance",
    charityProgramIds: [...BASE_CHARITY_IDS],
  },

  GA: {
    code: "GA",
    name: "Georgia",
    isMedicaidExpansion: false, // treat as non-expansion for simple rules
    medicaidAdultFplLimit: 0,
    medicaidUrl: "https://medicaid.georgia.gov/",
    chipUrl: "https://dch.georgia.gov/peachcare-kids",
    marketplaceUrl: "https://georgiaaccess.gov/",
    freeClinicSearchUrl: "https://nafcclinics.org/find-clinic/",
    hospitalFapInfoUrl: "https://your-hospital.org/financial-assistance",
    charityProgramIds: [...BASE_CHARITY_IDS, "GA_GCCN"],
  },

  FL: {
    code: "FL",
    name: "Florida",
    isMedicaidExpansion: false,
    medicaidAdultFplLimit: 0,
    medicaidUrl: "https://ahca.myflorida.com/medicaid",
    chipUrl: "https://www.floridakidcare.org/",
    marketplaceUrl: "https://www.healthcare.gov/marketplace-in-your-state/florida/",
    freeClinicSearchUrl: "https://nafcclinics.org/find-clinic/",
    hospitalFapInfoUrl: "https://your-hospital.org/financial-assistance",
    charityProgramIds: [...BASE_CHARITY_IDS, "FL_FAFCC"],
  },

  IL: {
    code: "IL",
    name: "Illinois",
    isMedicaidExpansion: true,
    medicaidAdultFplLimit: 138,
    medicaidUrl: "https://hfs.illinois.gov/",
    chipUrl: "https://hfs.illinois.gov/medicalprograms/allkids.html",
    marketplaceUrl: "https://getcoveredillinois.gov/",
    freeClinicSearchUrl: "https://nafcclinics.org/find-clinic/",
    hospitalFapInfoUrl: "https://your-hospital.org/financial-assistance",
    charityProgramIds: [...BASE_CHARITY_IDS],
  },

  KY: {
    code: "KY",
    name: "Kentucky",
    isMedicaidExpansion: true,
    medicaidAdultFplLimit: 138,
    medicaidUrl: "https://kynect.ky.gov/benefits/s/medicaid-kchip-program?language=en_US",
    chipUrl: "https://kidshealth.ky.gov/Pages/index.aspx",
    marketplaceUrl: "https://kynect.ky.gov/healthcoverage/",
    freeClinicSearchUrl: "https://nafcclinics.org/find-clinic/",
    hospitalFapInfoUrl: "https://your-hospital.org/financial-assistance",
    charityProgramIds: [...BASE_CHARITY_IDS],
  },

  MA: {
    code: "MA",
    name: "Massachusetts",
    isMedicaidExpansion: true,
    medicaidAdultFplLimit: 138,
    medicaidUrl: "https://www.mass.gov/topics/masshealth",
    chipUrl: "https://www.mass.gov/info-details/masshealth-for-children-and-young-adults",
    marketplaceUrl: "https://www.mahealthconnector.org/",
    freeClinicSearchUrl: "https://nafcclinics.org/find-clinic/",
    hospitalFapInfoUrl: "https://your-hospital.org/financial-assistance",
    charityProgramIds: [...BASE_CHARITY_IDS],
  },

  ME: {
    code: "ME",
    name: "Maine",
    isMedicaidExpansion: true,
    medicaidAdultFplLimit: 138,
    medicaidUrl: "https://www.maine.gov/dhhs/oms",
    chipUrl: "https://www.coverme.gov/learn/what-plans-are-available/mainecare",
    marketplaceUrl: "https://www.coverme.gov/",
    freeClinicSearchUrl: "https://nafcclinics.org/find-clinic/",
    hospitalFapInfoUrl: "https://your-hospital.org/financial-assistance",
    charityProgramIds: [...BASE_CHARITY_IDS],
  },

  MO: {
    code: "MO",
    name: "Missouri",
    isMedicaidExpansion: true,
    medicaidAdultFplLimit: 138,
    medicaidUrl: "https://mydss.mo.gov/healthcare",
    chipUrl: "https://mydss.mo.gov/healthcare/mo-healthnet-for-kids",
    marketplaceUrl: "https://www.healthcare.gov/marketplace-in-your-state/missouri/",
    freeClinicSearchUrl: "https://nafcclinics.org/find-clinic/",
    hospitalFapInfoUrl: "https://your-hospital.org/financial-assistance",
    charityProgramIds: [...BASE_CHARITY_IDS],
  },

  MS: {
    code: "MS",
    name: "Mississippi",
    isMedicaidExpansion: false,
    medicaidAdultFplLimit: 0,
    medicaidUrl: "https://medicaid.ms.gov/",
    chipUrl: "https://medicaid.ms.gov/programs/childrens-health-insurance-program-chip/",
    marketplaceUrl: "https://www.healthcare.gov/marketplace-in-your-state/mississippi/",
    freeClinicSearchUrl: "https://nafcclinics.org/find-clinic/",
    hospitalFapInfoUrl: "https://your-hospital.org/financial-assistance",
    charityProgramIds: [...BASE_CHARITY_IDS],
  },

  MT: {
    code: "MT",
    name: "Montana",
    isMedicaidExpansion: true,
    medicaidAdultFplLimit: 138,
    medicaidUrl: "https://dphhs.mt.gov/MontanaHealthcarePrograms/MemberServices",
    chipUrl: "https://dphhs.mt.gov/hmk/",
    marketplaceUrl: "https://www.healthcare.gov/marketplace-in-your-state/montana/",
    freeClinicSearchUrl: "https://nafcclinics.org/find-clinic/",
    hospitalFapInfoUrl: "https://your-hospital.org/financial-assistance",
    charityProgramIds: [...BASE_CHARITY_IDS],
  },

  NJ: {
    code: "NJ",
    name: "New Jersey",
    isMedicaidExpansion: true,
    medicaidAdultFplLimit: 138,
    medicaidUrl: "https://njfamilycare.dhs.state.nj.us/",
    chipUrl: "https://njfamilycare.dhs.state.nj.us/",
    marketplaceUrl: "https://www.getcovered.nj.gov/",
    freeClinicSearchUrl: "https://nafcclinics.org/find-clinic/",
    hospitalFapInfoUrl: "https://your-hospital.org/financial-assistance",
    charityProgramIds: [...BASE_CHARITY_IDS],
  },

  NY: {
    code: "NY",
    name: "New York",
    isMedicaidExpansion: true,
    medicaidAdultFplLimit: 138,
    medicaidUrl: "https://www.health.ny.gov/health_care/medicaid/",
    chipUrl: "https://info.nystateofhealth.ny.gov/ChildHealthPlus",
    marketplaceUrl: "https://nystateofhealth.ny.gov/",
    freeClinicSearchUrl: "https://nafcclinics.org/find-clinic/",
    hospitalFapInfoUrl: "https://your-hospital.org/financial-assistance",
    charityProgramIds: [...BASE_CHARITY_IDS],
  },

  OH: {
    code: "OH",
    name: "Ohio",
    isMedicaidExpansion: true,
    medicaidAdultFplLimit: 138,
    medicaidUrl: "https://medicaid.ohio.gov/",
    chipUrl: "https://medicaid.ohio.gov/FOR-OHIOANS/Programs/Children-Families-and-Women",
    marketplaceUrl: "https://www.healthcare.gov/marketplace-in-your-state/ohio/",
    freeClinicSearchUrl: "https://nafcclinics.org/find-clinic/",
    hospitalFapInfoUrl: "https://your-hospital.org/financial-assistance",
    charityProgramIds: [...BASE_CHARITY_IDS],
  },

  OR: {
    code: "OR",
    name: "Oregon",
    isMedicaidExpansion: true,
    medicaidAdultFplLimit: 138,
    medicaidUrl: "https://www.oregon.gov/oha/HSD/OHP/Pages/index.aspx",
    chipUrl: "https://www.oregon.gov/oha/HSD/OHP/Pages/index.aspx",
    marketplaceUrl: "https://www.oregonhealthcare.gov/",
    freeClinicSearchUrl: "https://nafcclinics.org/find-clinic/",
    hospitalFapInfoUrl: "https://your-hospital.org/financial-assistance",
    charityProgramIds: [...BASE_CHARITY_IDS],
  },

  PA: {
    code: "PA",
    name: "Pennsylvania",
    isMedicaidExpansion: true,
    medicaidAdultFplLimit: 138,
    medicaidUrl: "https://www.pa.gov/agencies/dhs/resources/medicaid",
    chipUrl: "https://www.pa.gov/agencies/dhs/resources/chip",
    marketplaceUrl: "https://www.pennie.com/",
    freeClinicSearchUrl: "https://nafcclinics.org/find-clinic/",
    hospitalFapInfoUrl: "https://your-hospital.org/financial-assistance",
    charityProgramIds: [...BASE_CHARITY_IDS],
  },

  SC: {
    code: "SC",
    name: "South Carolina",
    isMedicaidExpansion: false,
    medicaidAdultFplLimit: 0,
    medicaidUrl: "https://www.scdhhs.gov/",
    chipUrl: "https://www.scdhhs.gov/members/program-eligibility-and-income-limits",
    marketplaceUrl: "https://www.healthcare.gov/marketplace-in-your-state/south-carolina/",
    freeClinicSearchUrl: "https://nafcclinics.org/find-clinic/",
    hospitalFapInfoUrl: "https://your-hospital.org/financial-assistance",
    charityProgramIds: [...BASE_CHARITY_IDS],
  },

  VA: {
    code: "VA",
    name: "Virginia",
    isMedicaidExpansion: true,
    medicaidAdultFplLimit: 138,
    medicaidUrl: "https://coverva.dmas.virginia.gov/",
    chipUrl: "https://coverva.dmas.virginia.gov/learn/coverage-for-children/medicaid-for-children-and-famis/",
    marketplaceUrl: "https://www.marketplace.virginia.gov/",
    freeClinicSearchUrl: "https://nafcclinics.org/find-clinic/",
    hospitalFapInfoUrl: "https://your-hospital.org/financial-assistance",
    charityProgramIds: [...BASE_CHARITY_IDS, "VA_VAFCC"],
  },

  WA: {
    code: "WA",
    name: "Washington",
    isMedicaidExpansion: true,
    medicaidAdultFplLimit: 138,
    medicaidUrl: "https://www.hca.wa.gov/free-or-low-cost-health-care/apple-health-you",
    chipUrl: "https://www.hca.wa.gov/free-or-low-cost-health-care/apply-or-renew-coverage",
    marketplaceUrl: "https://www.wahealthplanfinder.org/",
    freeClinicSearchUrl: "https://nafcclinics.org/find-clinic/",
    hospitalFapInfoUrl: "https://your-hospital.org/financial-assistance",
    charityProgramIds: [...BASE_CHARITY_IDS],
  },

  WV: {
    code: "WV",
    name: "West Virginia",
    isMedicaidExpansion: true,
    medicaidAdultFplLimit: 138,
    medicaidUrl: "https://bms.wv.gov/",
    chipUrl: "https://chip.wv.gov/",
    marketplaceUrl: "https://www.healthcare.gov/marketplace-in-your-state/west-virginia/",
    freeClinicSearchUrl: "https://nafcclinics.org/find-clinic/",
    hospitalFapInfoUrl: "https://your-hospital.org/financial-assistance",
    charityProgramIds: [...BASE_CHARITY_IDS],
  },

  WI: {
    code: "WI",
    name: "Wisconsin",
    isMedicaidExpansion: false, // BadgerCare up to 100% FPL – not full ACA expansion
    medicaidAdultFplLimit: 0,
    medicaidUrl: "https://www.dhs.wisconsin.gov/badgercareplus/index.htm",
    chipUrl: "https://www.dhs.wisconsin.gov/badgercareplus/index.htm",
    marketplaceUrl: "https://www.healthcare.gov/marketplace-in-your-state/wisconsin/",
    freeClinicSearchUrl: "https://nafcclinics.org/find-clinic/",
    hospitalFapInfoUrl: "https://your-hospital.org/financial-assistance",
    charityProgramIds: [...BASE_CHARITY_IDS],
  },
};