// backend/eligibilityRulesModule.ts
// Rules-based eligibility engine (offline) using STATE_CONFIG and charities.

import express, { Request, Response } from "express";
import {
  STATE_CONFIG,
  CHARITY_PROGRAMS,
  StateCode,
} from "./eligibilityConfig";

type ConversationTurn = {
  role: "assistant" | "user";
  content: string;
};

type ScreeningRequest = {
  state: string; // 2-letter
  patientIntake: Record<string, any>;
  conversation: ConversationTurn[];
};

type SummaryProgram = {
  name: string;
  type:
    | "Medicaid/CHIP"
    | "Marketplace"
    | "Hospital Charity"
    | "Clinic/Charity"
    | "Rx/Diagnosis Assistance"
    | "Other";
  url?: string;
  keyCriteria?: string;
  notes?: string;
};

type SummaryResult = {
  state: string;
  eligibilityRationale: string;
  recommendedPrograms: SummaryProgram[];
  followupActions?: string[];
};

type StepResult =
  | {
      done: false;
      nextQuestion: string;
    }
  | {
      done: true;
      summary: SummaryResult;
    };

type PatientFacts = {
  state: string;
  age?: number;
  householdSize?: number;
  monthlyIncome?: number;
  isPregnantOrHasPregnantInHousehold?: boolean;
  hasChildrenInHousehold?: boolean;
  hasDisability?: boolean;
  insuranceStatus?: "uninsured" | "underinsured" | "insured";
  visitMedicallyNecessary?: boolean;
};

// ---------- SIMPLE FPL TABLE (approximate) ----------

const FPL_BASE_1 = 15000; // example annual FPL for household size 1
const FPL_ADD_PER_PERSON = 5300;

function estimateFplPercent(
  annualIncome: number,
  householdSize: number
): number {
  const base = FPL_BASE_1 + (householdSize - 1) * FPL_ADD_PER_PERSON;
  if (base <= 0) return 0;
  return (annualIncome / base) * 100;
}

// ---------- FACT DERIVATION ----------

function deriveFacts(
  stateCode: string,
  patientIntake: Record<string, any>,
  conversation: ConversationTurn[]
): PatientFacts {
  const facts: PatientFacts = {
    state: stateCode.toUpperCase(),
  };

  if (typeof patientIntake.age === "number") {
    facts.age = patientIntake.age;
  }
  if (typeof patientIntake.householdSize === "number") {
    facts.householdSize = patientIntake.householdSize;
  }
  if (typeof patientIntake.monthlyIncome === "number") {
    facts.monthlyIncome = patientIntake.monthlyIncome;
  }
  if (typeof patientIntake.isPregnant === "boolean") {
    facts.isPregnantOrHasPregnantInHousehold = patientIntake.isPregnant;
  }
  if (typeof patientIntake.hasChildrenInHousehold === "boolean") {
    facts.hasChildrenInHousehold = patientIntake.hasChildrenInHousehold;
  }
  if (typeof patientIntake.hasDisability === "boolean") {
    facts.hasDisability = patientIntake.hasDisability;
  }
  if (typeof patientIntake.insuranceStatus === "string") {
    facts.insuranceStatus = patientIntake.insuranceStatus;
  }
  if (typeof patientIntake.visitMedicallyNecessary === "boolean") {
    facts.visitMedicallyNecessary = patientIntake.visitMedicallyNecessary;
  }

  // Optionally: parse conversation to fill in missing facts.

  return facts;
}

// ---------- QUESTION FLOW ----------

function determineNextQuestion(facts: PatientFacts): string | null {
  if (!facts.householdSize) {
    return "How many people are in the patient’s household (including the patient)?";
  }
  if (!facts.monthlyIncome) {
    return "What is the household’s gross MONTHLY income before taxes?";
  }
  if (facts.isPregnantOrHasPregnantInHousehold === undefined) {
    return "Is the patient pregnant or is anyone in the household currently pregnant? (yes/no)";
  }
  if (facts.hasChildrenInHousehold === undefined) {
    return "Are there any children under age 19 living in the household? (yes/no)";
  }
  if (facts.hasDisability === undefined) {
    return "Does the patient have a disability or receive disability benefits? (yes/no)";
  }
  if (!facts.insuranceStatus) {
    return "Is the patient uninsured, underinsured (for example, very high deductible), or insured? (uninsured/underinsured/insured)";
  }
  if (facts.visitMedicallyNecessary === undefined) {
    return "Was this visit for emergent or medically necessary care? (yes/no)";
  }

  return null;
}

// ---------- SUMMARY BUILD ----------

function buildSummary(facts: PatientFacts): SummaryResult {
  const stateCode = facts.state.toUpperCase() as StateCode;
  const stateConfig = STATE_CONFIG[stateCode];

  const {
    monthlyIncome = 0,
    householdSize = 1,
    isPregnantOrHasPregnantInHousehold,
    hasChildrenInHousehold,
    hasDisability,
    insuranceStatus,
    visitMedicallyNecessary,
  } = facts;

  const annualIncome = monthlyIncome * 12;
  const fplPercent = estimateFplPercent(annualIncome, householdSize);

  const programs: SummaryProgram[] = [];
  const rationaleParts: string[] = [];

  rationaleParts.push(
    `Household size: ${householdSize}, monthly income: $${monthlyIncome.toFixed(
      2
    )}, estimated FPL: ~${fplPercent.toFixed(0)}%.`
  );

  if (stateConfig.isMedicaidExpansion) {
    rationaleParts.push(
      `${stateConfig.name} is a Medicaid expansion state with an approximate adult limit of ${stateConfig.medicaidAdultFplLimit}% FPL.`
    );
  } else {
    rationaleParts.push(
      `${stateConfig.name} is NOT a full Medicaid expansion state; adult coverage without children, pregnancy, or disability may be very limited.`
    );
  }

  let likelyMedicaid = false;
  let likelyChipOrKidsCoverage = false;

  if (
    stateConfig.isMedicaidExpansion &&
    fplPercent <= stateConfig.medicaidAdultFplLimit
  ) {
    likelyMedicaid = true;
    programs.push({
      name: `${stateConfig.name} Medicaid`,
      type: "Medicaid/CHIP",
      url: stateConfig.medicaidUrl,
      keyCriteria: `Adults with income up to ~${stateConfig.medicaidAdultFplLimit}% FPL; other categories may have different limits.`,
      notes:
        "Based on estimated FPL, the patient likely meets adult Medicaid income criteria.",
    });
  } else if (
    !stateConfig.isMedicaidExpansion &&
    (hasChildrenInHousehold ||
      isPregnantOrHasPregnantInHousehold ||
      hasDisability)
  ) {
    likelyMedicaid = true;
    rationaleParts.push(
      "Because there are children, pregnancy, or disability, the patient may qualify for Medicaid despite non-expansion status."
    );
    programs.push({
      name: `${stateConfig.name} Medicaid`,
      type: "Medicaid/CHIP",
      url: stateConfig.medicaidUrl,
      keyCriteria:
        "Eligibility may exist for parents, pregnant individuals, children, or disabled individuals even in non-expansion states.",
      notes:
        "Screen more closely for category-based Medicaid (parent, pregnant, disabled, child).",
    });
  }

  if (hasChildrenInHousehold || isPregnantOrHasPregnantInHousehold) {
    likelyChipOrKidsCoverage = true;
    if (stateConfig.chipUrl) {
      programs.push({
        name: `${stateConfig.name} Children's Coverage / CHIP`,
        type: "Medicaid/CHIP",
        url: stateConfig.chipUrl,
        keyCriteria:
          "Children and pregnant individuals often covered at higher FPL thresholds than adults.",
        notes:
          "Children in the household may qualify for CHIP or similar state child coverage.",
      });
    }
  }

  const isLikelyMarketplaceCandidate =
    fplPercent >= 100 &&
    (!likelyMedicaid || fplPercent > stateConfig.medicaidAdultFplLimit);

  if (isLikelyMarketplaceCandidate) {
    programs.push({
      name: `${stateConfig.name} ACA Marketplace Plans`,
      type: "Marketplace",
      url: stateConfig.marketplaceUrl,
      keyCriteria:
        "Most adults with income between ~100% and 400% FPL can qualify for premium tax credits and possibly cost-sharing reductions.",
      notes:
        "Patient may be eligible for subsidized ACA marketplace coverage based on estimated FPL.",
    });
  } else if (
    !stateConfig.isMedicaidExpansion &&
    fplPercent < 100 &&
    !likelyMedicaid
  ) {
    rationaleParts.push(
      "The patient may be in the coverage gap (income too low for subsidies but not eligible for Medicaid)."
    );
  }

  if (
    !insuranceStatus ||
    insuranceStatus === "uninsured" ||
    insuranceStatus === "underinsured"
  ) {
    programs.push({
      name: "Hospital Financial Assistance / Charity Care",
      type: "Hospital Charity",
      url: stateConfig.hospitalFapInfoUrl,
      keyCriteria:
        "Typically available for uninsured or underinsured patients up to a hospital-defined FPL threshold.",
      notes:
        visitMedicallyNecessary === false
          ? "Some programs require that the visit be medically necessary; verify with your hospital policy."
          : "Apply hospital financial assistance policy rules using patient income and household size.",
    });
  }

  programs.push({
    name: `${stateConfig.name} Free & Charitable Clinics`,
    type: "Clinic/Charity",
    url: stateConfig.freeClinicSearchUrl,
    keyCriteria:
      "Low-income, uninsured, or underinsured patients; many use sliding scale fees.",
    notes:
      "Use this directory to help the patient find ongoing primary care or specialty clinics in their area.",
  });

  const charityPrograms = stateConfig.charityProgramIds.map((id) => {
    const c = CHARITY_PROGRAMS[id];
    return {
      name: c.name,
      type:
        c.type === "Clinic/Charity Network"
          ? "Clinic/Charity"
          : "Rx/Diagnosis Assistance",
      url: c.url,
      keyCriteria: c.basicEligibility,
      notes: c.targetPopulation,
    } as SummaryProgram;
  });

  programs.push(...charityPrograms);

  const followupActions: string[] = [];

  if (likelyMedicaid) {
    followupActions.push(
      "Complete the state Medicaid/CHIP screening and assist the patient with an application."
    );
  }
  if (isLikelyMarketplaceCandidate) {
    followupActions.push(
      "Provide ACA Marketplace enrollment assistance or refer to a certified navigator."
    );
  }
  if (
    !stateConfig.isMedicaidExpansion &&
    fplPercent < 100 &&
    !likelyMedicaid &&
    (insuranceStatus === "uninsured" || insuranceStatus === "underinsured")
  ) {
    followupActions.push(
      "Explain the coverage gap and prioritize hospital charity care and free/low-cost clinic resources."
    );
  }
  if (
    !insuranceStatus ||
    insuranceStatus === "uninsured" ||
    insuranceStatus === "underinsured"
  ) {
    followupActions.push(
      "Help the patient apply for hospital financial assistance / charity care according to your FAP."
    );
  }

  followupActions.push(
    "Review national assistance organizations (PAN, HealthWell, PAF, NeedyMeds) for diagnosis- or medication-specific resources."
  );

  return {
    state: stateConfig.code,
    eligibilityRationale: rationaleParts.join(" "),
    recommendedPrograms: programs,
    followupActions,
  };
}

// ---------- MAIN STEP FUNCTION ----------

function runRulesStep(input: ScreeningRequest): StepResult {
  const stateCode = input.state.toUpperCase() as StateCode;
  const stateConfig = STATE_CONFIG[stateCode];

  if (!stateConfig) {
    return {
      done: true,
      summary: {
        state: input.state,
        eligibilityRationale:
          "No configuration found for this state. Please consult manual program resources.",
        recommendedPrograms: [],
      },
    };
  }

  const facts = deriveFacts(stateCode, input.patientIntake, input.conversation);
  const nextQuestion = determineNextQuestion(facts);

  if (nextQuestion) {
    return {
      done: false,
      nextQuestion,
    };
  }

  const summary = buildSummary(facts);
  return {
    done: true,
    summary,
  };
}

// ---------- EXPRESS ROUTE REGISTRATION ----------

export function registerEligibilityRoutes(app: express.Express) {
  app.post(
    "/api/eligibility/step_rules",
    (req: Request, res: Response): void => {
      try {
        const body = req.body as ScreeningRequest;
        const result = runRulesStep(body);
        res.json(result);
      } catch (err: any) {
        console.error("Eligibility rules step error:", err);
        res.status(400).json({
          error: "EligibilityRulesError",
          message: err?.message || "Unable to complete eligibility step.",
        });
      }
    }
  );
}