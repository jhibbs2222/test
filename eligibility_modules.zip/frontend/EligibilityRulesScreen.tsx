// frontend/EligibilityRulesScreen.tsx
import React, { useState } from "react";

type ConversationTurn = {
  role: "assistant" | "user";
  content: string;
};

type SummaryProgram = {
  name: string;
  type:
    | "Medicaid/CHIP"
    | "Marketplace"
    | "Hospital Charity"
    | "Clinic/Charity"
    | "Rx/Diagnosis Assistance"
    | "Other";
  url?: string;
  keyCriteria?: string;
  notes?: string;
};

type Summary = {
  state: string;
  eligibilityRationale: string;
  recommendedPrograms: SummaryProgram[];
  followupActions?: string[];
};

type Props = {
  state: string; // "GA", "AL", etc.
  patientIntake: Record<string, any>;
};

export const EligibilityRulesScreen: React.FC<Props> = ({
  state,
  patientIntake,
}) => {
  const [conversation, setConversation] = useState<ConversationTurn[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState<string | null>(
    "Tell the patient: 'I’m going to ask a few questions to see what help is available.' Then press Next."
  );
  const [answerInput, setAnswerInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [summary, setSummary] = useState<Summary | null>(null);
  const [error, setError] = useState<string | null>(null);

  const callStepApi = async (newConversation: ConversationTurn[]) => {
    setLoading(true);
    setError(null);
    try {
      const resp = await fetch("/api/eligibility/step_rules", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          state,
          patientIntake,
          conversation: newConversation,
        }),
      });

      if (!resp.ok) {
        throw new Error(`Server error ${resp.status}`);
      }

      const data = await resp.json();

      if (data.done) {
        setSummary(data.summary);
        setCurrentQuestion(null);
      } else {
        setCurrentQuestion(data.nextQuestion || null);
      }
    } catch (e: any) {
      setError(e.message || "Unable to continue screening.");
    } finally {
      setLoading(false);
    }
  };

  const handleNextClick = async () => {
    // Initial intro "question" – just start the rules engine.
    if (!summary && conversation.length === 0 && currentQuestion) {
      const newConv = [
        ...conversation,
        { role: "assistant" as const, content: currentQuestion },
      ];
      setConversation(newConv);
      await callStepApi(newConv);
      return;
    }

    if (!answerInput.trim()) return;

    const lastQuestion =
      currentQuestion || "Follow-up question asked by the assistant.";

    const newConv: ConversationTurn[] = [
      ...conversation,
      { role: "assistant", content: lastQuestion },
      { role: "user", content: answerInput.trim() },
    ];

    // NOTE: In this pure-rules version, we’re not parsing answers from conversation.
    // You can update `patientIntake` directly based on specific question IDs,
    // or extend the API to send structured updates instead of free text.
    setConversation(newConv);
    setAnswerInput("");
    await callStepApi(newConv);
  };

  return (
    <div
      style={{
        padding: "1rem",
        maxWidth: 600,
        margin: "0 auto",
        fontSize: "16px",
      }}
    >
      <h2 style={{ fontSize: "1.25rem", marginBottom: "0.5rem" }}>
        Eligibility Screening (Rules-Based)
      </h2>
      <p style={{ marginTop: 0, marginBottom: "0.5rem" }}>
        State: <strong>{state}</strong>
      </p>

      {!summary && (
        <>
          <div
            style={{
              border: "1px solid #ccc",
              borderRadius: 8,
              padding: "0.75rem",
              marginBottom: "0.75rem",
              minHeight: "3rem",
            }}
          >
            <strong>Ask the patient:</strong>
            <div style={{ marginTop: "0.5rem" }}>
              {currentQuestion || "Waiting for next question..."}
            </div>
          </div>

          <label
            style={{ display: "block", marginBottom: "0.25rem", fontSize: 14 }}
          >
            Patient's answer (type it here):
          </label>
          <textarea
            style={{
              width: "100%",
              minHeight: 80,
              padding: "0.5rem",
              borderRadius: 6,
              border: "1px solid #ccc",
              fontSize: "16px",
            }}
            value={answerInput}
            onChange={(e) => setAnswerInput(e.target.value)}
            disabled={loading}
          />

          {error && (
            <div
              style={{
                color: "#b00020",
                marginTop: "0.5rem",
                fontSize: 14,
              }}
            >
              {error}
            </div>
          )}

          <button
            style={{
              marginTop: "0.75rem",
              width: "100%",
              padding: "0.75rem",
              borderRadius: 999,
              border: "none",
              fontSize: "16px",
            }}
            onClick={handleNextClick}
            disabled={loading}
          >
            {loading ? "Working..." : "Next"}
          </button>
        </>
      )}

      {summary && (
        <div
          style={{
            marginTop: "1rem",
            borderTop: "1px solid #ddd",
            paddingTop: "0.75rem",
          }}
        >
          <h3 style={{ fontSize: "1.1rem" }}>Recommended Programs</h3>
          <p>{summary.eligibilityRationale}</p>

          <ul style={{ paddingLeft: "1.2rem" }}>
            {summary.recommendedPrograms.map((p, idx) => (
              <li key={idx} style={{ marginBottom: "0.5rem" }}>
                <strong>{p.name}</strong> ({p.type})
                {p.url && (
                  <>
                    {" "}
                    –{" "}
                    <a href={p.url} target="_blank" rel="noreferrer">
                      Open
                    </a>
                  </>
                )}
                {p.keyCriteria && <div>Criteria: {p.keyCriteria}</div>}
                {p.notes && <div>Notes: {p.notes}</div>}
              </li>
            ))}
          </ul>

          {summary.followupActions && summary.followupActions.length > 0 && (
            <>
              <h4 style={{ marginTop: "0.75rem" }}>Next steps for you</h4>
              <ul style={{ paddingLeft: "1.2rem" }}>
                {summary.followupActions.map((a, i) => (
                  <li key={i}>{a}</li>
                ))}
              </ul>
            </>
          )}
        </div>
      )}
    </div>
  );
};