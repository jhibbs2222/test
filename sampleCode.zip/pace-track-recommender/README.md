# PACE Track Recommender (No Spreadsheet Runtime Dependency)

This project embeds the active PACE track catalog generated from the provided spreadsheet **at build time**.

✅ Runtime does **NOT** load any Excel files.  
✅ Only PACE tracks with `IsActive=1` and `AgencyTypeCode='S'` were considered at generation time.  
✅ Tracks classified as **UNKNOWN** or **OPERATIONAL/INTERNAL** are excluded (not shown).  

Catalog summary embedded:
- Included states: 31
- Included tracks: 160
- Excluded (unknown/internal): 146

## Requirements
- Node.js 18+
- npm

## Install
```bash
npm install
```

## Run (dev)
```bash
npm run dev
```

- Backend: http://localhost:3001
- Frontend: http://localhost:5173

## Where to refine classification
- `backend/src/trackTaxonomy.ts` (PACE name → category)
- `backend/src/generated/paceCatalog.json` (embedded catalog, regenerate when spreadsheet changes)

## Regenerating catalog
This zip was generated from your spreadsheet already.
If the spreadsheet changes, rerun the generator script (not included here) or ask ChatGPT to regenerate.
