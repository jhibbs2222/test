export type NormalizedTrackType =
  | "MEDICAID_ADULT"
  | "MEDICAID_FAMILY"
  | "MEDICAID_PREGNANCY"
  | "MEDICAID_NEWBORN"
  | "MEDICAID_CHILD"
  | "MEDICAID_ABD"
  | "MEDICAID_LTC"
  | "MSP_QMB"
  | "SPENDDOWN_MEDICALLY_NEEDY"
  | "EMERGENCY_MEDICAID"
  | "RETRO_MEDICAID"
  | "PRESUMPTIVE_MEDICAID"
  | "CANCER_BCCP"
  | "WAIVER_PATHWAYS"
  | "OPERATIONAL_INTERNAL"
  | "UNKNOWN";

export type PatientFacts = {
  age?: number;
  isPregnant?: boolean;
  hasMedicare?: boolean;
  hasDisability?: boolean;
  needsLongTermCare?: boolean;
  monthlyIncome?: number;
  householdSize?: number;
  citizenshipLimited?: boolean;
  isNewborn?: boolean;
  hasChildrenInHousehold?: boolean;
};

export type QuestionDef = {
  id: keyof PatientFacts;
  text: string;
  input: "number" | "tri";
};

export const QUESTION_BANK: Record<string, QuestionDef> = {
  age: { id: "age", text: "What is the patient’s age?", input: "number" },
  isPregnant: { id: "isPregnant", text: "Is the patient pregnant now? (yes/no/unknown)", input: "tri" },
  hasMedicare: { id: "hasMedicare", text: "Does the patient have Medicare? (yes/no/unknown)", input: "tri" },
  needsLongTermCare: { id: "needsLongTermCare", text: "Is nursing home / long-term care placement needed? (yes/no/unknown)", input: "tri" },
  hasDisability: { id: "hasDisability", text: "Does the patient have a disability determination or receive disability benefits? (yes/no/unknown)", input: "tri" },
  householdSize: { id: "householdSize", text: "Household size (including patient):", input: "number" },
  monthlyIncome: { id: "monthlyIncome", text: "Household gross monthly income (estimate ok):", input: "number" },
  citizenshipLimited: { id: "citizenshipLimited", text: "Is full Medicaid eligibility limited due to citizenship/immigration status? (yes/no/unknown)", input: "tri" },
  hasChildrenInHousehold: { id: "hasChildrenInHousehold", text: "Any children under 19 in the household? (yes/no/unknown)", input: "tri" },
  isNewborn: { id: "isNewborn", text: "Is the patient a newborn/infant? (yes/no/unknown)", input: "tri" }
};

function hasAny(s: string, parts: string[]) {
  const l = s.toLowerCase();
  return parts.some((p) => l.includes(p.toLowerCase()));
}

function isExactCode(n: string, codes: string[]) {
  const x = n.trim().toUpperCase();
  return codes.includes(x);
}

export function classifyPaceName(stateCode: string, paceName: string): NormalizedTrackType {
  const n = (paceName ?? "").trim();

  if (
    hasAny(n, [
      "Advanced Payer Search","PreCert","Test Application","Authorization","Auth","Payer Search",
      "Search Commercial","Search Medicare","Verification"
    ])
  ) return "OPERATIONAL_INTERNAL";

  if (hasAny(n, ["PEN", "Pending", "in SUSPENSE"])) return "OPERATIONAL_INTERNAL";

  if (hasAny(n, ["All Kids","PeachCare","CHIP","KCHIP","KidCare","AllKids"])) return "MEDICAID_CHILD";

  if (isExactCode(n, ["QMB"]) || hasAny(n, ["Qualified Medicare Beneficiary"])) return "MSP_QMB";

  if (hasAny(n, ["Nursing Home","LTC","Long Term Care"])) return "MEDICAID_LTC";

  if (hasAny(n, ["Spenddown","SOC","Medically Needy"])) return "SPENDDOWN_MEDICALLY_NEEDY";

  if (hasAny(n, ["EMA", "Emergency Medicaid", "Emergency"])) return "EMERGENCY_MEDICAID";

  if (isExactCode(n, ["3MP"]) || hasAny(n, ["Retro"])) return "RETRO_MEDICAID";

  if (hasAny(n, ["Presumptive","30 Day Hospital"])) return "PRESUMPTIVE_MEDICAID";

  if (hasAny(n, ["BCCP","Cancer"])) return "CANCER_BCCP";

  if (stateCode.toUpperCase() === "GA" && hasAny(n, ["Pathways"])) return "WAIVER_PATHWAYS";

  if (hasAny(n, ["Pregnant","SOBRA","Right From The Start","RSM","RMS"])) {
    if (hasAny(n, ["Baby"])) return "MEDICAID_NEWBORN";
    if (hasAny(n, ["Child"])) return "MEDICAID_CHILD";
    return "MEDICAID_PREGNANCY";
  }

  if (hasAny(n, ["Newborn","Baby Add On"])) return "MEDICAID_NEWBORN";

  if (hasAny(n, ["MABD","Aged","Blind","Disabled"])) return "MEDICAID_ABD";

  if (hasAny(n, ["Family"])) return "MEDICAID_FAMILY";

  if (isExactCode(n, ["AMN","LIM"]) || hasAny(n, ["Adult","Low Income"])) return "MEDICAID_ADULT";

  if (hasAny(n, ["Medicaid Expansion","Childless Adult"])) return "MEDICAID_ADULT";

  if (hasAny(n, ["Medicaid ACE"])) return "MEDICAID_ADULT";

  return "UNKNOWN";
}

export function displayLabel(t: NormalizedTrackType): string {
  switch (t) {
    case "MEDICAID_ADULT": return "Adult Medicaid";
    case "MEDICAID_FAMILY": return "Family / Parent Medicaid";
    case "MEDICAID_PREGNANCY": return "Pregnancy Medicaid";
    case "MEDICAID_NEWBORN": return "Newborn / Infant Medicaid";
    case "MEDICAID_CHILD": return "Child Medicaid / CHIP track";
    case "MEDICAID_ABD": return "Aged/Blind/Disabled Medicaid";
    case "MEDICAID_LTC": return "Long Term Care Medicaid";
    case "MSP_QMB": return "Medicare Savings (QMB)";
    case "SPENDDOWN_MEDICALLY_NEEDY": return "Medically Needy / Spenddown";
    case "EMERGENCY_MEDICAID": return "Emergency Medicaid";
    case "RETRO_MEDICAID": return "Retroactive Medicaid";
    case "PRESUMPTIVE_MEDICAID": return "Presumptive / Hospital Medicaid";
    case "CANCER_BCCP": return "Breast & Cervical Cancer Medicaid";
    case "WAIVER_PATHWAYS": return "Georgia Pathways Waiver";
    default: return "Excluded";
  }
}

export function requiredFactsForTrack(t: NormalizedTrackType): (keyof PatientFacts)[] {
  switch (t) {
    case "MSP_QMB": return ["hasMedicare", "age"];
    case "MEDICAID_LTC": return ["needsLongTermCare"];
    case "MEDICAID_PREGNANCY": return ["isPregnant"];
    case "MEDICAID_NEWBORN": return ["age", "isNewborn"];
    case "MEDICAID_CHILD": return ["age"];
    case "MEDICAID_ABD": return ["hasDisability"];
    case "SPENDDOWN_MEDICALLY_NEEDY": return ["monthlyIncome", "householdSize"];
    case "EMERGENCY_MEDICAID": return ["citizenshipLimited"];
    case "RETRO_MEDICAID": return ["monthlyIncome", "householdSize"];
    case "PRESUMPTIVE_MEDICAID": return ["monthlyIncome", "householdSize"];
    case "MEDICAID_ADULT": return ["age", "monthlyIncome", "householdSize"];
    case "MEDICAID_FAMILY": return ["hasChildrenInHousehold", "monthlyIncome", "householdSize"];
    case "WAIVER_PATHWAYS": return ["age", "monthlyIncome", "householdSize"];
    default: return [];
  }
}
