import paceData from "./generated/paceCatalog.json";
import { classifyPaceName, displayLabel, requiredFactsForTrack, PatientFacts, QUESTION_BANK, NormalizedTrackType } from "./trackTaxonomy";

export type PaceTrack = { stateCode: string; applicationTypeId: number; name: string; };

export type TrackDecision = "RECOMMENDED" | "NON_RECOMMENDED";

export type TrackResult = {
  applicationTypeId: number;
  name: string;
  normalizedType: NormalizedTrackType;
  programLabel: string;
  decision: TrackDecision;
  reason: string;
};

export type NextStep =
  | { done: false; nextQuestionId: string; nextQuestionText: string; input: "number" | "tri" }
  | { done: true; recommended: TrackResult[]; nonRecommended: TrackResult[]; allIncluded: TrackResult[] };

export const SUMMARY = paceData.summary as {
  allStates: string[];
  includedStates: string[];
  totalTracksLoaded: number;
  excludedUnknownOrInternal: number;
};

export const CATALOG = paceData.catalog as Record<string, PaceTrack[]>;

function triToBool(v: any): boolean | undefined {
  if (v === true || v === "yes") return true;
  if (v === false || v === "no") return false;
  return undefined;
}

export function normalizeFacts(input: any): PatientFacts {
  const age = typeof input.age === "number" ? input.age : undefined;
  return {
    age,
    isPregnant: triToBool(input.isPregnant),
    hasMedicare: triToBool(input.hasMedicare),
    hasDisability: triToBool(input.hasDisability),
    needsLongTermCare: triToBool(input.needsLongTermCare),
    citizenshipLimited: triToBool(input.citizenshipLimited),
    householdSize: typeof input.householdSize === "number" ? input.householdSize : undefined,
    monthlyIncome: typeof input.monthlyIncome === "number" ? input.monthlyIncome : undefined,
    hasChildrenInHousehold: triToBool(input.hasChildrenInHousehold),
    isNewborn: (age !== undefined ? (age < 1) : triToBool(input.isNewborn)),
  };
}

function hasAllRequiredFacts(t: NormalizedTrackType, facts: PatientFacts): boolean {
  const req = requiredFactsForTrack(t);
  return req.every((k) => facts[k] !== undefined && facts[k] !== null);
}

export function decideTrack(track: PaceTrack, facts: PatientFacts): TrackResult {
  const t = classifyPaceName(track.stateCode, track.name);
  // At runtime we should never see excluded tracks (catalog is pre-filtered), but keep safe.
  if (t === "UNKNOWN" || t === "OPERATIONAL_INTERNAL") {
    return {
      applicationTypeId: track.applicationTypeId,
      name: track.name,
      normalizedType: t,
      programLabel: "Excluded",
      decision: "NON_RECOMMENDED",
      reason: "Excluded track type."
    };
  }

  // Some track-specific recommendation logic
  switch (t) {
    case "MSP_QMB":
      return facts.hasMedicare === true
        ? { ...base(track, t), decision: "RECOMMENDED", reason: "Medicare indicated; QMB is relevant." }
        : { ...base(track, t), decision: "NON_RECOMMENDED", reason: "Not recommended unless Medicare is confirmed." };

    case "MEDICAID_LTC":
      return facts.needsLongTermCare === true
        ? { ...base(track, t), decision: "RECOMMENDED", reason: "LTC placement indicated." }
        : { ...base(track, t), decision: "NON_RECOMMENDED", reason: "Not recommended unless LTC/nursing home need is indicated." };

    case "MEDICAID_PREGNANCY":
      return facts.isPregnant === true
        ? { ...base(track, t), decision: "RECOMMENDED", reason: "Pregnancy indicated." }
        : { ...base(track, t), decision: "NON_RECOMMENDED", reason: "Not recommended unless pregnant." };

    case "MEDICAID_NEWBORN":
      return facts.isNewborn === true
        ? { ...base(track, t), decision: "RECOMMENDED", reason: "Newborn/infant indicated." }
        : { ...base(track, t), decision: "NON_RECOMMENDED", reason: "Not recommended unless newborn/infant." };

    case "MEDICAID_CHILD":
      return (typeof facts.age === "number" && facts.age < 19)
        ? { ...base(track, t), decision: "RECOMMENDED", reason: "Patient under 19." }
        : { ...base(track, t), decision: "NON_RECOMMENDED", reason: "Not recommended unless patient is a child." };

    case "EMERGENCY_MEDICAID":
      return facts.citizenshipLimited === true
        ? { ...base(track, t), decision: "RECOMMENDED", reason: "Full Medicaid limited; Emergency Medicaid relevant." }
        : { ...base(track, t), decision: "NON_RECOMMENDED", reason: "Not recommended unless full Medicaid eligibility is limited." };

    default:
      if (!hasAllRequiredFacts(t, facts)) {
        return { ...base(track, t), decision: "NON_RECOMMENDED", reason: "More info needed to recommend; still selectable." };
      }
      return { ...base(track, t), decision: "RECOMMENDED", reason: "Relevant based on collected facts." };
  }
}

function base(track: PaceTrack, t: NormalizedTrackType) {
  return {
    applicationTypeId: track.applicationTypeId,
    name: track.name,
    normalizedType: t,
    programLabel: displayLabel(t),
  };
}

export function computeNextStep(stateCode: string, rawFacts: any): NextStep {
  const state = stateCode.toUpperCase();
  const tracks = CATALOG[state];
  if (!tracks) {
    return { done: true, recommended: [], nonRecommended: [], allIncluded: [] };
  }

  const facts = normalizeFacts(rawFacts);

  // Count missing facts across this state's included tracks
  const missingCounts = new Map<string, number>();
  for (const tr of tracks) {
    const t = classifyPaceName(state, tr.name);
    const req = requiredFactsForTrack(t);
    for (const k of req) {
      if (facts[k] === undefined || facts[k] === null) {
        const qid = String(k);
        if (QUESTION_BANK[qid]) missingCounts.set(qid, (missingCounts.get(qid) ?? 0) + 1);
      }
    }
  }

  const sorted = [...missingCounts.entries()].sort((a, b) => b[1] - a[1]);
  const best = sorted[0]?.[0];

  if (!best) {
    const allIncluded = tracks.map(t => decideTrack(t, facts));
    const recommended = allIncluded.filter(r => r.decision === "RECOMMENDED");
    const nonRecommended = allIncluded.filter(r => r.decision === "NON_RECOMMENDED");
    return { done: true, recommended, nonRecommended, allIncluded };
  }

  return { done: false, nextQuestionId: best, nextQuestionText: QUESTION_BANK[best].text, input: QUESTION_BANK[best].input };
}
