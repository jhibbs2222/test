import express, { Request, Response } from "express";
import { SUMMARY, CATALOG, computeNextStep } from "./paceEngine";

const router = express.Router();

router.get("/meta", (_req: Request, res: Response) => res.json(SUMMARY));

router.get("/states", (_req: Request, res: Response) => res.json({ states: SUMMARY.includedStates }));

router.get("/tracks/:state", (req: Request, res: Response) => {
  const state = String(req.params.state ?? "").toUpperCase();
  if (!CATALOG[state]) return res.status(404).json({ error: "State not supported." });
  return res.json({ state, tracks: CATALOG[state] });
});

router.post("/next-step", (req: Request, res: Response) => {
  const state = String(req.body?.state ?? "").toUpperCase();
  const patientIntake = req.body?.patientIntake ?? {};
  if (!CATALOG[state]) return res.status(400).json({ error: "Invalid or unsupported state." });
  return res.json(computeNextStep(state, patientIntake));
});

export default router;
