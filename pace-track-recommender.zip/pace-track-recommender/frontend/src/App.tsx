import { useEffect, useMemo, useState } from "react";

type TrackResult = {
  applicationTypeId: number;
  name: string;
  normalizedType: string;
  programLabel: string;
  decision: "RECOMMENDED" | "NON_RECOMMENDED";
  reason: string;
};

type DoneStep = {
  done: true;
  recommended: TrackResult[];
  nonRecommended: TrackResult[];
  allIncluded: TrackResult[];
};

type AskStep = {
  done: false;
  nextQuestionId: string;
  nextQuestionText: string;
  input: "number" | "tri";
};

type NextStep = DoneStep | AskStep;

type Meta = {
  allStates: string[];
  includedStates: string[];
  totalTracksLoaded: number;
  excludedUnknownOrInternal: number;
};

export default function App() {
  const [meta, setMeta] = useState<Meta | null>(null);
  const [stateCode, setStateCode] = useState<string>("");
  const [patientIntake, setPatientIntake] = useState<Record<string, any>>({});
  const [step, setStep] = useState<NextStep | null>(null);
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState<Record<number, boolean>>({});
  const [showNonRecommended, setShowNonRecommended] = useState(false);

  useEffect(() => {
    (async () => {
      const m = await fetch("/api/meta").then(r => r.json());
      setMeta(m);
      setStateCode(m?.includedStates?.[0] ?? "");
    })();
  }, []);

  const recommended = useMemo(() => (step && step.done ? step.recommended : []), [step]);
  const nonRecommended = useMemo(() => (step && step.done ? step.nonRecommended : []), [step]);

  async function fetchNext() {
    if (!stateCode) return;
    setLoading(true);
    try {
      const resp = await fetch("/api/next-step", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ state: stateCode, patientIntake }),
      });
      const data = (await resp.json()) as NextStep;
      setStep(data);

      if (data.done) {
        const nextSel: Record<number, boolean> = {};
        for (const r of data.recommended) nextSel[r.applicationTypeId] = true;
        setSelected(nextSel);
      }
    } finally {
      setLoading(false);
    }
  }

  function setAnswer(qid: string, value: any) {
    setPatientIntake(prev => ({ ...prev, [qid]: value }));
  }

  function toggle(id: number) {
    setSelected(prev => ({ ...prev, [id]: !prev[id] }));
  }

  function resetInterview() {
    setPatientIntake({});
    setStep(null);
    setSelected({});
    setShowNonRecommended(false);
  }

  function buildPayload() {
    if (!step || !step.done) return null;
    const chosen = step.allIncluded.filter(r => selected[r.applicationTypeId]);
    return {
      state: stateCode,
      selectedApplications: chosen.map(c => ({ applicationTypeId: c.applicationTypeId, name: c.name })),
      recommended: step.recommended.map(r => ({ applicationTypeId: r.applicationTypeId, name: r.name })),
      nonRecommended: step.nonRecommended.map(r => ({ applicationTypeId: r.applicationTypeId, name: r.name })),
      patientIntake,
    };
  }

  return (
    <div style={{ maxWidth: 980, margin: "0 auto", padding: 16, fontFamily: "system-ui" }}>
      <h2>PACE Track Recommender (Embedded Catalog)</h2>
      {meta && (
        <div style={{ color: "#444", marginBottom: 10 }}>
          Included states: <b>{meta.includedStates.length}</b> • Included tracks: <b>{meta.totalTracksLoaded}</b> • Excluded UNKNOWN/INTERNAL: <b>{meta.excludedUnknownOrInternal}</b>
        </div>
      )}

      <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 12 }}>
        <label>
          State:&nbsp;
          <select value={stateCode} onChange={(e) => { setStateCode(e.target.value); resetInterview(); }}>
            <option value="" disabled>Select…</option>
            {(meta?.includedStates ?? []).map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </label>

        <button onClick={fetchNext} disabled={loading || !stateCode}>
          {step ? (step.done ? "Re-run" : "Continue") : "Start"}
        </button>

        <button onClick={resetInterview} disabled={loading || (!step && Object.keys(patientIntake).length === 0)}>
          Reset
        </button>
      </div>

      {!step && (
        <div style={{ padding: 12, border: "1px solid #ddd", borderRadius: 8 }}>
          Click <b>Start</b>. The system asks the minimum questions needed for this state’s PACE tracks.
          <div style={{ marginTop: 6, color: "#666" }}>
            UNKNOWN/INTERNAL tracks are excluded from the lists by design.
          </div>
        </div>
      )}

      {step && !step.done && (
        <div style={{ padding: 12, border: "1px solid #ddd", borderRadius: 8 }}>
          <div style={{ fontWeight: 700, marginBottom: 8 }}>Question</div>
          <div style={{ marginBottom: 12 }}>{step.nextQuestionText}</div>

          <AnswerInput
            input={step.input}
            onSubmit={(val) => {
              setAnswer(step.nextQuestionId, val);
              fetchNext();
            }}
          />

          <details style={{ marginTop: 10 }}>
            <summary style={{ cursor: "pointer" }}>Collected so far</summary>
            <pre style={{ whiteSpace: "pre-wrap" }}>{JSON.stringify(patientIntake, null, 2)}</pre>
          </details>
        </div>
      )}

      {step && step.done && (
        <>
          <div style={{ marginTop: 14, padding: 12, border: "1px solid #ddd", borderRadius: 8 }}>
            <div style={{ fontWeight: 800, marginBottom: 10 }}>Recommended PACE Applications</div>
            {recommended.length === 0 && <div>No recommended applications based on collected facts (you can still choose below).</div>}
            {recommended.map(r => (
              <TrackRow key={r.applicationTypeId} r={r} checked={!!selected[r.applicationTypeId]} onToggle={() => toggle(r.applicationTypeId)} />
            ))}
          </div>

          <div style={{ marginTop: 14, padding: 12, border: "1px solid #ddd", borderRadius: 8 }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div style={{ fontWeight: 800 }}>Non-recommended (expert override)</div>
              <button onClick={() => setShowNonRecommended(v => !v)}>
                {showNonRecommended ? "Hide" : `Show (${nonRecommended.length})`}
              </button>
            </div>

            {showNonRecommended && (
              <div style={{ marginTop: 10 }}>
                {nonRecommended.map(r => (
                  <TrackRow key={r.applicationTypeId} r={r} checked={!!selected[r.applicationTypeId]} onToggle={() => toggle(r.applicationTypeId)} />
                ))}
              </div>
            )}
          </div>

          <div style={{ marginTop: 14, padding: 12, border: "1px solid #ddd", borderRadius: 8 }}>
            <div style={{ fontWeight: 800, marginBottom: 8 }}>PACE Payload Preview (ID + Name)</div>
            <pre style={{ whiteSpace: "pre-wrap" }}>{JSON.stringify(buildPayload(), null, 2)}</pre>
          </div>
        </>
      )}
    </div>
  );
}

function TrackRow({ r, checked, onToggle }: { r: TrackResult; checked: boolean; onToggle: () => void }) {
  return (
    <label style={{ display: "block", padding: "8px 0", borderBottom: "1px solid #eee" }}>
      <input type="checkbox" checked={checked} onChange={onToggle} />
      <span style={{ marginLeft: 10, fontWeight: 700 }}>
        {r.name} <span style={{ fontWeight: 400, color: "#666" }}>({r.programLabel})</span>
      </span>
      <div style={{ marginLeft: 28, color: "#555", marginTop: 4 }}>
        {r.reason}
        <div style={{ color: "#888", marginTop: 2 }}>
          PACE: ApplicationTypeID={r.applicationTypeId}
        </div>
      </div>
    </label>
  );
}

function AnswerInput({ input, onSubmit }: { input: "number" | "tri"; onSubmit: (val: any) => void }) {
  const [val, setVal] = useState<string>("");
  return (
    <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
      {input === "number" ? (
        <input type="number" value={val} onChange={(e) => setVal(e.target.value)} placeholder="Enter number" />
      ) : (
        <select value={val} onChange={(e) => setVal(e.target.value)}>
          <option value="">Select…</option>
          <option value="yes">Yes</option>
          <option value="no">No</option>
          <option value="unknown">Unknown</option>
        </select>
      )}

      <button
        onClick={() => {
          if (input === "number") onSubmit(val === "" ? undefined : Number(val));
          else onSubmit(val === "" || val === "unknown" ? undefined : val);
          setVal("");
        }}
      >
        Submit
      </button>
    </div>
  );
}
